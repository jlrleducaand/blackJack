(() => {
// VARIABLES
    let cartasArray = [];
    let carta = "";
    const palos = ["C", "D", "H", "S"];
    const figuras = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
    const valores = [2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 1];
    const reversos = ["gray_back", "red_back"];
    const maxPoint = 21;


    const vBtnNuevoJuego = document.getElementById('btnNuevo');
    const vBtnPedirCarta = document.getElementById('btnPedir');
    const vBtnDetener = document.getElementById('btnDetener');
    const zonaJugador = document.getElementById('jugador-cartas');
    const zonaCompu = document.getElementById('computadora-cartas');

    const zContJug = document.querySelector('#jug small');
    const zContCompu = document.querySelector('#compu small');
    let jugandoEn = "";
    let valorContPuntosJug = 0;
    let valorContPuntosCompu = 0;
    let valor;

// FUNCIONES
    vBtnNuevoJuego.addEventListener("click", nuevoJuego);
    vBtnPedirCarta.addEventListener('click', pedirCarta);
    vBtnDetener.addEventListener('click', detenerJugador);

    function nuevoJuego() {
        // Crea Baraja
        for (let i = 0; i < palos.length; i++) {               // Palos
            for (let j = 0; j < valores.length; j++) {        // Valores
                carta = figuras[j] + palos[i];
                cartasArray.push(carta);
            }
        }
        //console.log(cartasArray);

        // Mezclar la Baraja
        cartasArray = _.shuffle(cartasArray);
        //console.log(cartasArray);

        //resetear valores
        jugandoEn = "zonaJugador";
        zonaJugador.innerHTML = "";
        console.log("Borrado cartas jugador")
        zonaCompu.innerHTML = "";
        console.log("Borrado cartas Compu")
        valorContPuntosJug = 0;
        zContJug.textContent = valorContPuntosJug;
        valorContPuntosCompu = 0;
        zContCompu.textContent = valorContPuntosCompu;
        despiertaBotones();
    }

    function despiertaBotones() {
        vBtnPedirCarta.addEventListener('click', pedirCarta);
        vBtnDetener.addEventListener('click', detenerJugador);
        //console.log("botones despertados");
    }

    function pedirCarta() {

        // recoge la carta de la baraja
        let nuevaCarta = cartasArray.pop();     // saca la carta de la baraja
        valor = valorCarta(nuevaCarta);         // recupera int valor
        //console.log("nuevaCarta");
        creaPintaCarta(nuevaCarta);
    }

    function valorCarta(str) {
        let strValor = str.slice(0, str.length - 1);
        let indCarta = figuras.indexOf(strValor);
        let intCarta = valores[indCarta];
        //console.log("valorCarta");
        return intCarta;
    }

    function creaPintaCarta(carta) {
        // crea la etiqueta img y la agrega a su correspondiente div
        const imgCarta = document.createElement('img');
        imgCarta.setAttribute('src', strImgCarta(carta));
        imgCarta.classList.add('class', 'carta');
        logica(imgCarta);
        //console.log("creaCarta");
    }

    function strImgCarta(str) {

        let vCartaDir = "assets/cartas/" + str + ".png";
        //console.log("StrCartaDir");
        return vCartaDir;
    }

    function logica(img) {
        // Lógica de Juego para cada jugador
        if (jugandoEn === 'zonaJugador') {

            zonaJugador.append(img);                    //pega la imagen
            valorContPuntosJug += valor;                // suma los puntos
            zContJug.textContent = valorContPuntosJug;  // cambia el valor small

            verificaPuntos(valorContPuntosJug);

        } else if (jugandoEn === 'zonaCompu' && valorContPuntosCompu < maxPoint) {

            zonaCompu.append(img);                          //pega la imagen
            valorContPuntosCompu += valor;                  // suma los puntos
            zContCompu.textContent = valorContPuntosCompu;  // cambia el valor small

            verificaPuntos(valorContPuntosCompu);
        }
    }

    function verificaPuntos(puntos) {
        // console.log("verifica Puntos Pasados")
        if (jugandoEn === 'zonaJugador' && puntos > maxPoint) {

            detenerJugador();
        }
        if (jugandoEn === 'zonaCompu' && puntos > maxPoint) {
            mensajes();
        }
    }

    function detenerJugador() {
        jugandoEn = 'zonaCompu';        // cambio a zona Compu
        vBtnPedirCarta.removeEventListener('click', pedirCarta);
        vBtnDetener.removeEventListener('click', detenerJugador);
        juegaCompu();
    }

    function juegaCompu() {
        let pasadoJug = valorContPuntosJug > maxPoint;
        let vencedorJug = ((valorContPuntosJug > valorContPuntosCompu) && (!pasadoJug));

        if (pasadoJug) {
            pedirCarta();
            mensajes();

        } else{
            do {
                pedirCarta();
            } while ((valorContPuntosCompu < maxPoint) && (valorContPuntosCompu < valorContPuntosJug));
            mensajes();
        }
    }

    function mensajes() {
        let texto = "";
        if (valorContPuntosJug <= maxPoint && valorContPuntosCompu <= maxPoint ){
            if (valorContPuntosJug == valorContPuntosCompu) {
                texto = ("Lo sentimos pero en caso de empate gana la Casa");
                delay(texto);
            }else if (valorContPuntosJug > valorContPuntosCompu){
                texto = ("Enhorabuena  has ganado por puntos a la Casa");
                delay(texto);
            }else if (valorContPuntosJug < valorContPuntosCompu){
                texto = ("Lo Sentimos pierdes por Puntos");
                delay(texto);
            }
        }else if (valorContPuntosJug > maxPoint){
            texto = ("Lo sentimos Te has pasado de 21 Gana la Casa");
            delay(texto);
        }else {
            texto = ("Enhorabuena  has ganado a la Casa se paso");
            delay(texto);
        }

        ressetProcesos();
    }

    function delay(texto) {
        setTimeout(() => alert(texto), 200);
    }

    function ressetProcesos() {

        jugandoEn = "zonaJugador";

    }

})()
